﻿$scriptPath = Split-Path $script:MyInvocation.MyCommand.Path
& $scriptPath\installService.ps1 -auto-register --Name=SDLWebLiveDeployerService --Description="SDL Web Live Deployer Service" `
    --DisplayName="SDL Web Live Deployer Service" --server.port=9084 --DependsOn=SDLWebLiveDiscoveryService `
    -Ddbtype="OracleSQL" -Ddbclass="oracle.jdbc.pool.OracleDataSource" `
    -Ddbhost="APP036.svb.org" -Ddbport="1521" -Ddbname="TWBR" -Ddbuser="TridionBrokerUser_live" `
    -Ddbpassword="Br0kerlive" -Ddbadapter="oracle" -Ddbdriver="oracle.jdbc.driver.OracleDriver" `
    -DqueuePath="F:\Apps\SDLWebDeliveryLive\deployer\Queue" -DbinaryPath="F:\Apps\SDLWebDeliveryLive\deployer\Binary"