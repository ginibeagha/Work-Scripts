﻿$scriptPath = Split-Path $script:MyInvocation.MyCommand.Path
& $scriptPath\installService.ps1 --Name=SDLWebStagingDiscoveryService `
 --Description="SDL Web Staging Discovery Service" `
    --DisplayName="SDL Web Staging Discovery Service" --server.port=8082 `
    -Ddbtype="OracleSQL" -Ddbclass="oracle.jdbc.pool.OracleDataSource" `
    -Ddbhost="APP036.svb.org" -Ddbport="1521" -Ddbname="TWDR" -Ddbuser="TridionDiscoveryUser_staging" `
    -Ddbpassword="Disc0veryStaging"

