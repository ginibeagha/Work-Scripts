﻿$scriptPath = Split-Path $script:MyInvocation.MyCommand.Path
& $scriptPath\installService.ps1 -auto-register --Name=SDLWebStagingSession ContentService --Description="SDL Web Staging Session Content Service" `
    --DisplayName="SDL Web Staging Session Content Service" --server.port=8081 --DependsOn=SDLWebStagingDiscoveryService `
     -Ddbtype="OracleSQL" -Ddbclass="oracle.jdbc.pool.OracleDataSource" `
    -Ddbhost="APP036.svb.org" -Ddbport="1521" -Ddbname="TWBR" -Ddbuser="TridionBrokerUser_staging" `
    -Ddbpassword="Br0kerStaging" -Ddbsessionname="TWPR" -Ddbsessionuser="TridionPreviewUser" -Ddbsessionpassword="Prev1ew"
