﻿$scriptPath = Split-Path $script:MyInvocation.MyCommand.Path
& $scriptPath\installService.ps1 -auto-register --Name=SDLWebStagingDeployerService --Description="SDL Web Staging Deployer Service" `
    --DisplayName="SDL Web Staging Deployer Service" --server.port=8084 --DependsOn=SDLWebStagingDiscoveryService `
     -Ddbtype="OracleSQL" -Ddbclass="oracle.jdbc.pool.OracleDataSource" `
    -Ddbhost="APP036.svb.org" -Ddbport="1521" -Ddbname="TWBR" -Ddbuser="TridionBrokerUser_staging" `
    -Ddbpassword="Br0kerStaging" -Ddbadapter="oracle" -Ddbdriver="oracle.jdbc.driver.OracleDriver" `
    -DqueuePath="F:\Apps\SDLWebDeliveryStaging\deployer\Queue" -DbinaryPath="F:\Apps\SDLWebDeliveryStaging\deployer\Binary" `
    