﻿$scriptPath = Split-Path $script:MyInvocation.MyCommand.Path
& $scriptPath\installService.ps1 -auto-register --Name=SDLWebLiveContentService --Description="SDL Web Live Content Service" `
    --DisplayName="SDL Web Live Content Service" --server.port=9081 --DependsOn=SDLWebLiveDiscoveryService `
     -Ddbtype="OracleSQL" -Ddbclass="oracle.jdbc.pool.OracleDataSource" `
    -Ddbhost="APP036.svb.org" -Ddbport="1521" -Ddbname="TWBR" -Ddbuser="TridionBrokerUser_live" `
    -Ddbpassword="Br0kerlive"