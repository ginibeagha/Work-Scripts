﻿#Set your source (installer uzipped) location and Install (microservices root) location
 $sourceLocation='F:\Source\SDL Web 8.5\Content Delivery\roles' 
 $InstallLocation= 'F:\Apps\TestInstallScript'
 
 #Add or remove services using exact names used in the installer - there are more, these are the ones Im interested in
 $StagingMicroservices= 'deployer-combined', 'discovery', 'session', 'preview', 'caching'
 $LiveMicroservices= 'deployer-combined', 'discovery', 'caching', 'content'
 
 #start by setting the source location so we can start copying
 Set-Location $sourceLocation
 
 #Make the staging and live root locations as needed
 $stagingLocation=md $InstallLocation"\SDLWebDeliveryStaging"
 $liveLocation=md $InstallLocation"\SDLWebDeliveryLive"

 #copy standalone folders to staging microservice folders
 gci -Recurse -d |?{$_.Name -in $StagingMicroservices}|gci -r -Directory |?{$_.Name -match 'standalone'}|%{
    $addon= ($_.FullName -split "\\")[5]
    Write-Host "$stagingLocation\$addon"
    Copy-Item $_.FullName -Destination "$stagingLocation\$addon" -Recurse
    }

 #copy standalone folders to live microservice folders
    gci -Recurse -d |?{$_.Name -in $LiveMicroservices}|gci -r -Directory |?{$_.Name -match 'standalone'}|%{
    $addon= ($_.FullName -split "\\")[5]
    Write-Host "$liveLocation\$addon"
    Copy-Item $_.FullName -Destination "$liveLocation\$addon" -Recurse
    }
    