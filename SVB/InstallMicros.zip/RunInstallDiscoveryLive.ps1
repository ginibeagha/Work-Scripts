﻿$scriptPath = Split-Path $script:MyInvocation.MyCommand.Path
& $scriptPath\installService.ps1 --Name=SDLWebLiveDiscoveryService --Description="SDL Web Live Discovery Service" `
    --DisplayName="SDL Web Live Discovery Service" --server.port=9082 `
     -Ddbtype="OracleSQL" -Ddbclass="oracle.jdbc.pool.OracleDataSource" `
    -Ddbhost="APP036.svb.org" -Ddbport="1521" -Ddbname="TWDR" -Ddbuser="TridionDiscoveryUser_live" `
    -Ddbpassword="Disc0veryLive"